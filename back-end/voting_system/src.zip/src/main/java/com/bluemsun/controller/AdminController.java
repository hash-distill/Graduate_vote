package com.bluemsun.controller;


import com.bluemsun.entity.User;
import com.bluemsun.entity.dto.ResultDto;
import com.bluemsun.service.UserService;
import com.bluemsun.utils.CustomUserComparator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.jws.soap.SOAPBinding;
import javax.print.attribute.standard.MediaSize;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static org.apache.tomcat.util.bcel.classfile.ElementValue.STRING;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {
    private final Integer PRENUM = 2; // 预选的数量，最初商量是2个，害怕以后会更改，写成属性吧
    @Autowired
    UserService userService;
    /**
     * 批量录入待选人信息，上传待选人的信息，excel文件，文件name为file
     * @param file
     * @return
     */
    @RequestMapping("/uploadExcel")
    public ResultDto<Object> uploadExcel(@RequestParam("file") MultipartFile file){
        ResultDto<Object> rt = new ResultDto<>();
        // 处理上传的Excel文件
        if (!file.isEmpty()) {
            try {
                byte[] bytes = file.getBytes();
                // 在这里可以调用相应的处理方法对Excel文件进行处理
                // 例如，可以使用Apache POI或其他Java库来解析Excel文件
                // 在文件上传处理方法中处理Excel文件
//                Workbook workbook = new XSSFWorkbook(new ByteArrayInputStream(bytes)); // 根据Excel格式选择适当的Workbook
                Workbook workbook = new XSSFWorkbook(new ByteArrayInputStream(bytes));
                Sheet sheet = workbook.getSheetAt(1); // 获取工作表
                int i = 0;
                List<User> list = new ArrayList<>();
                for (Row row : sheet) {

                    Cell nameCell = row.getCell(1);
                    Cell genderCell = row.getCell(2);
                    Cell politicsCell = row.getCell(3);
                    Cell collegeCell = row.getCell(4);

                    if (nameCell != null && genderCell != null && politicsCell != null && collegeCell != null) {
                        String name = nameCell.getStringCellValue();
                        String gender = genderCell.getStringCellValue();
                        String politics = politicsCell.getStringCellValue();
                        String college = collegeCell.getStringCellValue();

                        // 在这里可以对解析出的数据进行处理，例如打印或存储到数据结构中
                        System.out.println("姓名: " + name);
                        System.out.println("性别: " + gender);
                        System.out.println("政治面貌: " + politics);
                        System.out.println("学院: " + college);
                        System.out.println("----------------------");
                        if(!"".equals(name) && name!=null && !"姓名".equals(name)){
                            int gender_temp = 0;
                            if(gender.equals("男")){
                                gender_temp = 1;
                            }
                            User user = new User(name, gender_temp, politics, college, 0);
                            list.add(user);
                        }
                    }
                }
                workbook.close(); // 关闭Workbook
                boolean success = userService.insertAll(list);
                if(success){
                    rt.setMsg("上传成功");
                    rt.setResult(success);
                    rt.setData(list);
                } else {
                    rt.setMsg("存入数据库失败");
                    rt.setResult(success);
                }

                return rt;
            } catch (IOException e) {
                e.printStackTrace();
                rt.setResult(false);
                rt.setMsg("上传失败");
                return rt;
            }
        } else {
            rt.setResult(false);
            rt.setMsg("文件不能为空");

            return rt;
        }
    }

    /**
     * 单个录入待选人的信息
     *
     * @param user
     * @return
     */
    @RequestMapping("/uploadPeople")
    public ResultDto<Object> uploadPeople(@RequestBody User user){
        ResultDto<Object> rt = new ResultDto<>();
        boolean success = userService.insertOne(user);
        rt.setResult(success);
        if(success){
            rt.setMsg("学生信息录入成功");
            rt.setData(null);
        } else {
            rt.setMsg("学生信息录入失败");
            rt.setData(null);
        }
        return rt;
    }

    /**
     * 设置每个人最多投多少票，以及有多少位老师参与投票，选中几位同学
     * @param map
     * @param request
     * @return
     */
    @RequestMapping("/setMsg")
    public ResultDto<Object> setLimitAndTeachers(@RequestBody Map<String,Integer> map, HttpServletRequest request){
        ResultDto<Object> rt = new ResultDto<>(false, "设置失败", null);;
        Integer limit = map.get("limit");
        Integer teachers = map.get("teachers");
        Integer teachers_all = teachers;
        Integer students = map.get("students");
        if(limit!=null && teachers!=null && students!=null){
            rt = new ResultDto<>(true, "设置成功", null);
        }
        ServletContext application = request.getServletContext();
        application.setAttribute("limit", limit);
        application.setAttribute("teachers", teachers);
        application.setAttribute("students", students);
        application.setAttribute("teachers_all", teachers_all);
        application.setAttribute("isRevote", 0);
        application.setAttribute("revote", null);
        application.setAttribute("last", new ArrayList<User>());
        application.setAttribute("pre", new ArrayList<User>());     // 候补名单
        application.setAttribute("formal", new ArrayList<User>());   // 正选名单
        application.setAttribute("isPreRevote", false);
//        application.setAttribute("determineNum", 0);
        application.setAttribute("revoteTimes", 0);
        application.setAttribute("revoteResult", new HashMap<Integer, Map<String, Object>>());
        application.setAttribute("preRevoteTimes", 0);
        application.setAttribute("preRevoteResult", new HashMap<Integer, Map<String, Object>>());
        application.setAttribute("all", null);

        application.setAttribute("begin", -1);
        boolean success = userService.setPollZero();    // 将票数归0
        return rt;
    }

    /**
     * 获取投票结果
     * @param request
     * @return 哪些学生平票了，需要重新投票
     */
    @RequestMapping("/getVoteResult")
    public ResultDto<Object> getVotesNum(HttpServletRequest request){
        ResultDto<Object> rt = new ResultDto<>();
        ServletContext application = request.getServletContext();

        int limit = 0;
        int teachers = 0;
        int students = 0;
        int teachers_all = 0;
        try {
            limit = (int) application.getAttribute("limit");
            teachers = (int) application.getAttribute("teachers");
            students = (int) application.getAttribute("students");
            teachers_all = (int) application.getAttribute("teachers_all");
        } catch (Exception e){
            rt.setResult(false);
            rt.setMsg("请管理员先设置投票限制和老师数量");
            return rt;
        }
        List<User> formal = (List<User>) application.getAttribute("formal");
        List<User> last = (List<User>) application.getAttribute("last");
        List<User> pre = (List<User>) application.getAttribute("pre");
        List<User> users = (List<User>) application.getAttribute("revote");
        if(users == null){
            if(last.size() == (int)application.getAttribute("students")){
                users = last;
            } else {
                users = userService.getAllUsers();
            }

        } else {
            students = (int) application.getAttribute("limit");
        }

        Map<String, Object> map = new HashMap<>();
        map.put("limit", limit);
        map.put("teachersNum", teachers);
        map.put("students", users);
        map.put("teachers_all", teachers_all);
        map.put("revote", null);
        map.put("isRevote", (int)application.getAttribute("isRevote"));
        map.put("pre", null);
        map.put("isPreRevote", (boolean)application.getAttribute("isPreRevote"));    // 重投的是候补，是：true，否：false
        CustomUserComparator comparator = new CustomUserComparator();   // 学院比较器
        // 返回第一轮投票
        if(application.getAttribute("all") == null && (int)application.getAttribute("isRevote")!=0){
            List<User> list = userService.getAllUsers();
            list.sort(comparator);
            application.setAttribute("all", list);
        }
        map.put("all", application.getAttribute("all"));

        if(users != null){
            if(pre.size() == PRENUM){ // 投票结束
                userService.updatePollToFirst(pre);
                userService.updatePollToFirst(last);
                map.put("pre", pre);
                map.put("students", last);

                application.setAttribute("isRevote", 0);
                application.setAttribute("revote", null);
                application.setAttribute("determineNum", pre.size()+last.size());
            } else{
                // 按照票数降序排序

                users.sort(comparator);
                // 确定正选+候补总名单
                if(!((boolean) application.getAttribute("isPreRevote")) && teachers==0 && limit!=0 && (int)application.getAttribute("isRevote")!=1){  // 保证是投票结束，而不是还没有设置
                    if(last.size() != (int)application.getAttribute("students")+PRENUM) { // 27个人还没确定
                        // 需要重投，保留前一次重投的结果
                        if((List<User>)application.getAttribute("revote") != null){
                            application.setAttribute("revoteTimes", (int)application.getAttribute("revoteTimes")+1);
                            Map<Integer, Map<String, Object>> revoteResult = (Map<Integer, Map<String, Object>>)application.getAttribute("revoteResult");
                            List<User> listTemp = new ArrayList<>();
                            for(User user: (List<User>)application.getAttribute("revote")){
                                listTemp.add(User.getUser(user));
                            }
                            Map<String, Object> map_temp = new HashMap<>();
                            map_temp.put("limit", application.getAttribute("limit"));
                            map_temp.put("revoteList", listTemp);
                            revoteResult.put((Integer) application.getAttribute("revoteTimes"), map_temp);
                        }
                        Map<String, Object> map1 = userService.getRevote(users, students, last);
                        List<User> revoteList = (List<User>) map1.get("revoteList");
                        if (revoteList.size() != 0) {
                            application.setAttribute("isRevote", 1);
                            application.setAttribute("revote", revoteList);
                            application.setAttribute("limit", (int) map1.get("limit"));
                            map.put("limit", (int) map1.get("limit"));
                        }
//                        else{
//                            application.setAttribute("revote", null);
//                        }
                        map.put("revote", revoteList);
                        map.put("isRevote", (int) application.getAttribute("isRevote"));
                    } else {
                        List<User> revote = (List<User>) application.getAttribute("revote");
                        // 处理27人确定后的重投
                        if(formal.size() == (int)application.getAttribute("students")){
                            // 正选已经确定，是候补的重投
                            if(!Objects.equals(revote.get(0).getVotePoll(), revote.get(1).getVotePoll())){
                                // 第1个和第2个不同，候补确定
                                pre.add(revote.get(0));
                                pre.add(revote.get(1));

                                map.put("pre", pre);

                                application.setAttribute("isRevote", 0);
                                application.setAttribute("revote", null);
                                application.setAttribute("determineNum", pre.size()+last.size());
                            } else {
                                // 依然一样，再次重投

                                // 票数置0
                                revote.get(0).setVotePoll(0);
                                revote.get(1).setVotePoll(0);

                                map.put("revote", revote);
                                map.put("isRevote", 1);
                            }
                        } else {
                            // 正选的重投
                            int begin = (int) application.getAttribute("begin");
                            int formalNum = (int) application.getAttribute("students");
                            if(!Objects.equals(revote.get(formalNum - begin).getVotePoll(), revote.get(formalNum - begin - 1).getVotePoll())){
                                // 第25和第26不同，正选可以确定，不用再重投
                                boolean isEnd = false;
                                for (User user : revote) {
                                    if (begin == formalNum && !isEnd) {
                                        isEnd = true;
                                    }
                                    if (!isEnd) {
                                        formal.add(user);
                                    }
                                    last.set(begin, user);
                                    begin++;
                                }

                                // 确定候补

                            } else {
                                // 25和26平，还需要再次重投
                                int target = revote.get(formalNum-begin).getVotePoll();
                                int limit_tmp = 0;
                                boolean isFirst = false;
                                for(int i = 0; i < revote.size(); i++){
                                    if(revote.get(i).getVotePoll() != target){
                                        // 这一个不需要再次重投，添加确定名单
                                        User remove = revote.remove(i);// 把确定了的移除
                                        formal.add(remove);
                                        begin ++;
                                    } else {
                                        if(!isFirst){
                                            isFirst = true;
                                            limit_tmp = formalNum-begin;
                                            application.setAttribute("begin", begin);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if(last.size() == (int)application.getAttribute("students")+PRENUM){    // 27个人已经确定了
                        int formalNum = (int) application.getAttribute("students");
                        if(!Objects.equals(last.get(formalNum - 1).getVotePoll(), last.get(formalNum).getVotePoll())){
                            // 25和26不同，正选已经确定
                            if(formal.size() != formalNum){
                                // 正选名单中还没人，添加
                                for(int i = 0; i < formalNum; i++){
                                    formal.add(last.get(i));
                                }
                            }
                            // 确定候补
                            if(!Objects.equals(last.get(formalNum).getVotePoll(), last.get(formalNum + 1).getVotePoll())){
                                // 26和27不同，说明第一候补和第二候补已经确定，投票结束
                                pre.add(last.get(formalNum));
                                pre.add(last.get(formalNum+1));
                                map.put("pre", pre);

                                application.setAttribute("isRevote", 0);
                                application.setAttribute("revote", null);
                                application.setAttribute("determineNum", pre.size()+last.size());
                            } else {
                                // 26和27相同，需要重投，确定第一候补和第二候补
                                List<User> revote = new ArrayList<>();
                                revote.add(last.get(formalNum));
                                revote.add(last.get(formalNum+1));
                                application.setAttribute("begin", formalNum);
                                application.setAttribute("revote", revote);
                                application.setAttribute("isRevote", 1);
                                map.put("revote", revote);
                            }
                        } else {
                            // 需要重投去顶正选
                            int target = last.get(formalNum-1).getVotePoll();
                            List<User> revote = new ArrayList<>();
                            int limit_tmp = 0;
                            boolean isFirst = false;
                            for(int i = 0; i < formalNum+PRENUM; i++){
                                if(last.get(i).getVotePoll() == target){
                                    revote.add(last.get(i));
                                    if(i < formalNum){
                                        limit_tmp++;
                                    }
                                    if(!isFirst){
                                        isFirst = true;
                                        application.setAttribute("begin", i);
                                    }
                                }
                                if(!isFirst){
                                    formal.add(last.get(i));
                                }
                            }
                            application.setAttribute("revote", revote);
                            application.setAttribute("isRevote", 1);
                            map.put("revote", revote);
                        }
                    }

                }
            }

            // 设置已经确定了多少人
            map.put("determineNum", pre.size()+formal.size());
            map.put("revoteResult", application.getAttribute("revoteResult"));
            map.put("preRevoteResult", application.getAttribute("preRevoteResult"));
            rt.setMsg("success");
            rt.setResult(true);
            rt.setData(map);
        } else {

            rt.setResult(false);
            rt.setMsg("fail");
            rt.setData(null);
        }

        return rt;
    }
}
