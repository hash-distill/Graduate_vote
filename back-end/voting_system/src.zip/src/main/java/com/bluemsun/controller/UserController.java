package com.bluemsun.controller;

import com.bluemsun.entity.User;
import com.bluemsun.entity.dto.ResultDto;
import com.bluemsun.service.UserService;
import com.bluemsun.utils.CustomUserComparatorInsti;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@CrossOrigin
//@RequestMapping("/user")
public class UserController {

    private static final Object lock = new Object();

    @Autowired
    UserService userService;
    @RequestMapping("/hello")
    public ResultDto<String> hello(){
        return new ResultDto<>(true, "hello", "hello");
    }

    /**
     * 获取全部待选人
     * @param request
     * @return
     */
    @GetMapping("/users")
    public ResultDto<Object> getAll(HttpServletRequest request){
        ResultDto<Object> rt = new ResultDto<>();
        ServletContext application = request.getServletContext();
        List<User> users = (List<User>) application.getAttribute("revote");
        if(users != null) {
            if((int)application.getAttribute("isRevote")==1) {
                application.setAttribute("teachers", application.getAttribute("teachers_all"));
                application.setAttribute("isRevote", (int) application.getAttribute("isRevote") + 1);
            }
        } else{
            users = userService.getAllUsers();
        }
        Map<String, Object> map = new HashMap<>();

        if(application.getAttribute("limit") == null){
            rt.setResult(false);
            rt.setMsg("请管理员先设置投票限制和老师数量");
            return rt;
        }
        users.sort(new CustomUserComparatorInsti());
        map.put("limit", application.getAttribute("limit"));
        map.put("teachersNum", application.getAttribute("teachers"));
        map.put("students", users);

        rt.setMsg("success");
        rt.setResult(true);
        rt.setData(map);

        return rt;
    }

    /**
     * 投票，接收数组数据，里面存对应学生的id（数据库的主键）
     * @param students
     * @param request
     * @return
     */
    @RequestMapping("/vote")
    public ResultDto<Object> vote(@RequestBody List<Integer> students, HttpServletRequest request){
        ResultDto<Object> rt = new ResultDto<>();
        ServletContext application = request.getServletContext();
        Map<String, Object> map = new HashMap<>();
        if(application.getAttribute("limit") == null){
            rt.setResult(false);
            rt.setMsg("请管理员先设置投票限制和老师数量");
            return rt;
        }
        map.put("limit", application.getAttribute("limit"));

        boolean success = true;
        // 可能多个老师同时投票，保证线程安全
        synchronized(lock){
            List<User> revote = (List<User>) application.getAttribute("revote");
            if(revote != null){
                for(User user : revote){
                    for(Integer id: students){
                        if (Objects.equals(user.getVoteId(), id)){
                            user.setVotePoll(user.getVotePoll()+1);
                        }
                    }
                }
            } else {
                success = userService.updateByIds(students);
            }
        }
        rt.setResult(success);
        if(success){
            rt.setMsg("投票成功");
            synchronized(lock){
                int teachers = (int) application.getAttribute("teachers");
                teachers = teachers-1;
                application.setAttribute("teachers", teachers);
            }
            map.put("teachersNum", application.getAttribute("teachers"));
            rt.setData(map);

        } else {
            rt.setMsg("投票失败");
            map.put("teachersNum", application.getAttribute("teachers"));
            rt.setData(map);
        }
        return rt;
    }
}
