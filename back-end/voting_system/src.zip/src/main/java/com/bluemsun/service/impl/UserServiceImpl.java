package com.bluemsun.service.impl;

import com.bluemsun.dao.UserDao;
import com.bluemsun.entity.User;
import com.bluemsun.service.UserService;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserDao userDao;
    @Override
    public List<User> getAllUsers() {
        return userDao.selectAll();
    }

    @Override
    public boolean insertOne(User user) {
        int result = userDao.insertOne(user);
        return result==1;
    }

    @Override
    public boolean updateByIds(List<Integer> students) {
        for (int id: students) {
             id = userDao.updateById(id);
             if(id != 1){
                 return false;
             }
        }
        return true;
    }

    @Override
    public Map<String, Object> getRevote(List<User> list, int students, List<User> last) {
        List<User> users = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        int limit = 0;
        if(Objects.equals(list.get(students - 1).getVotePoll(), list.get(students).getVotePoll())) {
            //选中的最后一个人的票数和没选中的第一个人的票数相等，说明这俩人需要重新投票
            //统计需要重新投票的学生
            boolean isFirst = false;
            int targetVotes = list.get(students).getVotePoll();
            for (int i = 0; i < list.size(); i++) {
                //如果后面还有人与上面两人票数相同就添加
                if (list.get(i).getVotePoll() == targetVotes) {
                    list.get(i).setVotePoll(0);
                    users.add(list.get(i));
                    if(i <= students-1){
                        limit++;
                    }
                    if(!isFirst){
                        isFirst = true;
                    }
                }
                if(!isFirst){
                    last.add(list.get(i));
                }
            }
        } else {
            for(int i = 0; i < students; i++){
                last.add(list.get(i));
            }
        }
        map.put("revoteList", users);
        map.put("limit", limit);
        return map;
    }

    // 2个候补
    @Override
    public Map<String, Object> getPreRevote(List<User> list, int students, List<User> pre) {
        List<User> users = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        int limit = 0;
        if(students == 2){
            if(list.size() >= 3){
                if(Objects.equals(list.get(1).getVotePoll(), list.get(2).getVotePoll())){   // 第2个人和第三个人平票，需要重投，并计算重投人数
                    if(!Objects.equals(list.get(0).getVotePoll(), list.get(1).getVotePoll())){
                        pre.add(list.get(0));   // 第1个人和第二个人不同，那第一个人必定是第一候补
                    }

                    int targetVotes = list.get(1).getVotePoll();
                    for(int i = 0; i < list.size(); i++){
                        if(list.get(i).getVotePoll() == targetVotes){
                            list.get(i).setVotePoll(0);
                            users.add(list.get(i));
                            if(i <= students-1){
                                limit++;
                            }
                        }
                    }

                } else {
                    if(!Objects.equals(list.get(0).getVotePoll(), list.get(1).getVotePoll())){
                        pre.add(list.get(0));   // 前3个都不平票，第一候补和第二候补确定
                        pre.add(list.get(1));
                    } else {
                        list.get(0).setVotePoll(0);
                        list.get(1).setVotePoll(0);
                        users.add(list.get(0)); // 只有第1和第2个平票，这俩重投，确定第一候补和第二候补
                        users.add(list.get(1));
                        limit = 1;
                    }
                }
            } else { // 只有2个人，直接判断这俩人是否平票
                if(Objects.equals(list.get(0).getVotePoll(), list.get(1).getVotePoll())){
                    users.add(list.get(0)); // 第1和第2个平票，这俩重投，确定第一候补和第二候补
                    users.add(list.get(1));
                    limit = 1;
                } else {
                    pre.add(list.get(0));   // 不平票，第一候补和第二候补确定
                    pre.add(list.get(1));
                }
            }
        } else if(students == 1) { // 第一候补已经确定，确定第二候补

            if(Objects.equals(list.get(0).getVotePoll(), list.get(1).getVotePoll())){
                // 前两个平票，重投
                int targetVotes = list.get(1).getVotePoll();
                for(int i = 0; i < list.size(); i++){
                    if(list.get(i).getVotePoll() == targetVotes){
                        list.get(i).setVotePoll(0);
                        users.add(list.get(i));
                        if(i <= students-1){
                            limit++;
                        }
                    }
                }
            } else {
                // 前两个不平票，确定第二候选
                pre.add(list.get(0));
            }
        }

        map.put("revoteList", users);
        map.put("limit", limit);
        return map;
    }

    @Override
    public boolean insertAll(List<User> users) {
        for(User user: users){
            int i = userDao.insertOne(user);
            if(i != 1){
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean setPollZero() {
        return userDao.setAllPollZero()>=0;
    }

    @Override
    public boolean updatePollToFirst(List<User> list) {
        for(User user: list){
            User u = userDao.updatePollToFirst(user.getVoteId());
            user.setVotePoll(u.getVotePoll());
        }
        return true;
    }

}
