package com.bluemsun.service;

import com.bluemsun.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

public interface UserService {
    public List<User> getAllUsers();

    public boolean insertOne(User user);

    public boolean updateByIds(List<Integer> students);

    public Map<String, Object> getRevote(List<User> list, int students, List<User> last);

    public Map<String, Object> getPreRevote(List<User> list, int students, List<User> pre);

    public boolean insertAll(List<User> users);

    public boolean setPollZero();

    public boolean updatePollToFirst(List<User> list);
}
